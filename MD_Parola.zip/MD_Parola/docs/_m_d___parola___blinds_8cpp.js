var _m_d___parola___blinds_8cpp =
[
    [ "BLINDS_SIZE", "_m_d___parola___blinds_8cpp.html#a08e3a3dd505127a0e472ffd8ac378177", null ]
];